package com.Java.CrudJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
